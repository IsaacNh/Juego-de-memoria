//: Playground - noun: a place where people can play

import UIKit

var rango = 0...100     //declaración del rango de 0 a 100


for i in rango{     //ciclo for para imprimir los 101 números
    
    var con1 = ""       //variable para imprimir condición 1
    var con2 = ""       //variable para imprimir condición 2
    var con3 = ""       //variable para imprimir condición 3
    var con4 = ""       //variable para imprimir condición 4
    
    if (i % 5) == 0{        //verificación de la 1ª condición
    con1 = " \t#\(i) Bingo!!!"
    }
    if (i % 2) == 0{        //verificación de la 2ª condición
    con2 = " \t#\(i) Par!!!"
    }else{                  //verificación de la 3ª condición
    con3 = " \t#\(i) Impar!!!"
    }
    switch i {          //verificación de la 4ª condición
    case 30...40:
        con4 = " \t#\(i) Viva Swift!!!"
    default : break
        
    }
    
    //impresión de mesajes con la interpolación de las 4 variables
    
    print("\(i) \(con1) \(con2) \(con3) \(con4)")
    
}


